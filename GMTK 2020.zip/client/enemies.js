function enemies() {




}